
export default function App(){
  return <h1>SoalCerdas Ready 🚀</h1>
}
