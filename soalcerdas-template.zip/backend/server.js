
import express from "express";
import cors from "cors";

const app = express();
app.use(cors());
app.use(express.json());

app.post("/api/generate", (req,res)=>{
  res.json({
    soal: [
      { soal: "Contoh soal 1", jawaban: "A" }
    ]
  });
});

app.listen(3001, ()=>console.log("running"));
